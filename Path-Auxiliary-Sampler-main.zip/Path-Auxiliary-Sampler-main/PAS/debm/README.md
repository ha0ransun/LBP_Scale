# setup

Download the folder [https://github.com/jmtomczak/vae_vampprior/tree/master/datasets](https://github.com/jmtomczak/vae_vampprior/tree/master/datasets) to your data folder, and the folder should look like

```
YOUR_DATA_FOLDER/
    Caltech...
    FreyFaces...
    Histo...
    MNIST_static/
    Omniglot/
```

