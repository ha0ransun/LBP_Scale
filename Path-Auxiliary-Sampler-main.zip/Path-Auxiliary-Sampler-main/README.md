# Official Repo for ICLR 2022 Paper: [Path Auxiliary Proposal for MCMC in Discrete Space](https://openreview.net/pdf?id=JSR-YDImK95)
